#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "simplelist.h"

struct paciente {
  char nombre[100];
  int edad;
  char enfermedad[100];
  
};


/* Otras funciones */
void limpiarPantalla() {
  system("clear");
}

void PresionaEnter() {
  printf("Presione Enter para continuar...");
  while (getchar() != '\n'); // Limpiar el búfer de entrada

  while (getchar() != '\n'); // Limpiar el búfer de entrada
}
  
 // 1
void registrar_paciente(List *L_b, List *L_m)
{
  limpiarPantalla();
  //ingreso info paciente nuevo
  struct paciente *paciente_nuevo = (struct paciente *)malloc(sizeof(struct paciente));

  //Nombre
  while (getchar() != '\n'); // Limpiar el búfer de entrada
  printf("Ingrese el nombre del paciente: "); 
  scanf("%s", paciente_nuevo->nombre);
  //Edad
  while (getchar() != '\n'); // Limpiar el búfer de entrada
  printf("Ingrese la edad del paciente: ");
  scanf("%d", &paciente_nuevo->edad);
  if (paciente_nuevo->edad <= 0) //verificacion de edad mayor a 0
  {
    printf("\nLa edad ingresada no es válida.\n");
    free(paciente_nuevo);
    PresionaEnter();
    return;
  }

  while (getchar() != '\n'); //limpiar buffer
  
  //Enfermedad
  printf("Ingrese la enfermedad del paciente: ");
  scanf("%s", paciente_nuevo->enfermedad);

  //Salida de info paciente nuevo

  if ((paciente_nuevo->edad >= 60) || (paciente_nuevo->edad <= 3)) { //Se condiciona para pacientes mayores de 60 años y menores de 3 años
    pushBack(L_m, paciente_nuevo); //Se agrega el paciente a la lista de pacientes de media prioridad.
    printf("\nEl/la paciente %s ha sido registrada automaticamente en la lista de media prioridad\n", paciente_nuevo->nombre);
  }
  else {
    pushBack(L_b, paciente_nuevo); //Se agrega el paciente a la lista de pacientes de baja prioridad.
    printf("\nEl/la paciente %s ha sido registrada automaticamente en la lista de baja prioridad\n", paciente_nuevo->nombre);
  }
  PresionaEnter();
  
}

// 2
// Esta funcion permite asignar y reasignar la prioridad a un paciente.
void asignar_prioridad(List *L_B, List *L_M, List *L_A)
{
  limpiarPantalla();

  //VARIABLES
  char opcion;
  char nombre[100];
  struct paciente *paciente_encontrado = NULL;
  printf("Escoja una lista de pacientes  \n1) Baja Prioridad\n2) Media Prioridad\n3) Alta Prioridad\n");
  while (getchar() != '\n'); //limpiar buffer
  scanf( " %c", &opcion);
  switch (opcion)
  {
      case '1': //BAJA PRIORIDAD
        //Comprobemos que no está vacía
        if (get_size(L_B) == 0) {
          printf("No hay pacientes en la lista de baja prioridad.\n");
          PresionaEnter();
          return;
        }
        printf("Escriba el nombre del paciente que deseas reasignar su prioridad: "); //Solicitamos el nombre del paciente
        while (getchar() != '\n'); //limpiar buffer
        scanf("%s", nombre);
        struct paciente *paciente_actual = (struct paciente *)first(L_B); //Buscamos el nombre
        for (int i = 0; i < get_size(L_B); i++) {
          if (strcmp(paciente_actual->nombre, nombre) == 0) {
            popCurrent(L_B); //Lo eliminamos de la lista en la que estaba
            paciente_encontrado = paciente_actual; 
            break;
          }
        paciente_actual = next(L_B);  
          
 
        }
        if (paciente_encontrado == NULL) {
          printf("No se encontró ningún paciente con ese nombre en la lista de baja prioridad\n");
          PresionaEnter();
          return;
        }
        //Asignamos prioridad
        while(1) {
        printf("Escoja la lista de pacientes a donde desea asignar al paciente\n1) Media Prioridad\n2) Alta Prioridad\n");
        while (getchar() != '\n'); //limpiar buffer
        scanf( " %c", &opcion);
        
        switch (opcion) { //SELECCION DE LISTA
          case '1':
            pushBack(L_M, paciente_encontrado);
            printf("El/la paciente %s ha sido asignado a la lista de media prioridad\n", paciente_encontrado->nombre);
            PresionaEnter();
            return;

          case '2':
            pushBack(L_A, paciente_encontrado);
            printf("El/la paciente %s ha sido asignado a la lista de Alta prioridad\n", paciente_encontrado->nombre);
            PresionaEnter();
            return;

          default:
            printf("Por favor, escoja una opción válida.\n");
          }
        }
  

  case '2': //MEDIA PRIORIDAD
    //Comprobemos que no está vacía
    if (get_size(L_M) == 0) {
      printf("No hay pacientes en la lista de media prioridad.\n");
      PresionaEnter();
      return;
    }
    printf("Escriba el nombre del paciente que deseas reasignar su prioridad: ");
    while (getchar() != '\n'); //limpiar buffer
    scanf("%s", nombre);
    paciente_actual = (struct paciente *)first(L_M);
    for (int i = 0; i < get_size(L_M); i++) {
      if (strcmp(paciente_actual->nombre, nombre) == 0) {
        popCurrent(L_M);
        paciente_encontrado = paciente_actual;
        break;
      }
    paciente_actual = next(L_M);   


    }
    if (paciente_encontrado == NULL) {
      printf("No se encontró ningún paciente con ese nombre en la lista de media prioridad\n");
      PresionaEnter();
      return;
    }
    //Asignamos prioridad
    while(1) {
    printf("Escoja la lista de pacientes a donde desea asignar al paciente\n1) Baja Prioridad\n2) Alta Prioridad\n");
    while (getchar() != '\n'); //limpiar buffer
    scanf( " %c", &opcion);

    switch (opcion) { //SELECCION DE LISTA
      case '1':
        pushBack(L_B, paciente_encontrado);
        printf("El/la paciente %s ha sido asignado a la lista de baja prioridad\n", paciente_encontrado->nombre);
        PresionaEnter();
        return;

      case '2':
        pushBack(L_A, paciente_encontrado);
        printf("El/la paciente %s ha sido asignado a la lista de Alta prioridad\n", paciente_encontrado->nombre);
        PresionaEnter();
        return;

      default:
        printf("Por favor, escoja una opción válida.\n");
      }
    }
    

  case '3' : //ALTA PRIORIDAD
    //Comprobemos que no está vacía
    if (get_size(L_A) == 0) {
      printf("No hay pacientes en la lista de alta prioridad.\n");
      PresionaEnter();
      return;
    }
    printf("Escriba el nombre del paciente que deseas reasignar su prioridad: ");
    while (getchar() != '\n'); //limpiar buffer
    scanf("%s", nombre);
    paciente_actual = (struct paciente *)first(L_A);
    for (int i = 0; i < get_size(L_A); i++) {
      if (strcmp(paciente_actual->nombre, nombre) == 0) {
        popCurrent(L_A);
        paciente_encontrado = paciente_actual;
        break;
      }
    paciente_actual = next(L_A);   


    }
    if (paciente_encontrado == NULL) {
      printf("No se encontró ningún paciente con ese nombre en la lista de Alta prioridad\n");
      PresionaEnter();
      return;
    }
    //Asignamos prioridad
    while(1) {
    printf("Escoja la lista de pacientes a donde desea asignar al paciente\n1) Baja Prioridad\n2) Media Prioridad\n");
    while (getchar() != '\n'); //limpiar buffer
    scanf( " %c", &opcion);

    switch (opcion) { //SELECCION DE LISTA
      case '1':
        pushBack(L_B, paciente_encontrado);
        printf("El/la paciente %s ha sido asignado a la lista de baja prioridad\n", paciente_encontrado->nombre);
        PresionaEnter();
        return;

      case '2':
        pushBack(L_M, paciente_encontrado);
        printf("El/la paciente %s ha sido asignado a la lista de media prioridad\n", paciente_encontrado->nombre);
        PresionaEnter();
        return;

      default:
        printf("Por favor, escoja una opción válida.\n");
      }
    }
      
  default :
    printf("Opción inválida.\n");
    PresionaEnter();
  }
}

// 3 
//Funcion que muestra en que orden serán atendidos los pacientes
void mostrar_lista(List *L_b, List *L_m, List *L_a) {
  limpiarPantalla();
  printf("Lista de pacientes en orden según prioridad y hora de asignación\n");
  printf("----------------------------------------------------------------\n");
  struct paciente *paciente_actual = (struct paciente *)first(L_a);
  for (int i = 0; i < get_size(L_a); i++) { //PRIMERO MUESTRA LOS ALTOS
    printf("[Nombre: %s]\n", paciente_actual->nombre);
    paciente_actual = next(L_a);
  }
  paciente_actual = (struct paciente *)first(L_m); //DESPUES MUESTRA LOS MEDIOS
  for (int i = 0; i < get_size(L_m); i++) {
    printf("[Nombre: %s]\n", paciente_actual->nombre);
    paciente_actual = next(L_m);
  }
  paciente_actual = (struct paciente *)first(L_b); //POR ULTIMO MUESTRA LOS BAJOS
  for (int i = 0; i < get_size(L_b); i++) {
    printf("[Nombre: %s]\n", paciente_actual->nombre);
    paciente_actual = next(L_b);  
  }
  printf("\n");  
  PresionaEnter();
}

// 4
//Esta funcion elimina el primer paciente de la lista de espera (vease la funcion mostrar_lista)
void atender_paciente(List *L_b, List *L_m, List *L_a) {
  limpiarPantalla();
  struct paciente *paciente_atendido = NULL;
  //ATENDER ALTA PRIORIDAD (si está vacía, pasa a la siguiente lista)
  if (get_size(L_a) != 0) {
    paciente_atendido = popFront(L_a);
    printf("El/la paciente %s con la enfermedad %s ha sido atendido\n", paciente_atendido->nombre, paciente_atendido->enfermedad);
    free(paciente_atendido);
    PresionaEnter();
  }
   //ATENDER MEDIA PRIORIDAD  (si está vacía, pasa a la siguiente lista)
  else if (get_size(L_m) != 0) {
    paciente_atendido = popFront(L_m);
    printf("El/la paciente %s con la enfermedad %s ha sido atendido\n", paciente_atendido->nombre, paciente_atendido->enfermedad);
    free(paciente_atendido);
    PresionaEnter();
  }
    //ATENDER BAJA PRIORIDAD (si está vacía, no hay pacientes que atender)
  else if (get_size(L_b) != 0) {
    paciente_atendido = popFront(L_b);
    printf("El/la paciente %s con la enfermedad %s ha sido atendido\n", paciente_atendido->nombre, paciente_atendido->enfermedad);
    free(paciente_atendido);
    PresionaEnter();
  }
  else {
    printf("No hay pacientes en la lista de atención\n");
    PresionaEnter();
  }
    
}

// 5
void mostrar_prioridad(List *L_b, List *L_m, List *L_a)
{
  limpiarPantalla();
  char opcion;
  struct paciente *paciente_actual = NULL;
  printf("Ingrese la prioridad que desea examinar\n1) Baja Prioridad\n2) Media Prioridad\n3) Alta Prioridad\n");
  while (getchar() != '\n'); //limpiar buffer
  scanf("%c", &opcion);

  //Switch
  switch(opcion) {
    case '1':
      printf("Lista de pacientes en baja prioridad:\n\n"); //Mostrar lista de baja prioridad
      paciente_actual = (struct paciente *)first(L_b);
      for (int i = 0; i < get_size(L_b); i++) {
        printf("[Nombre: %s, Edad: %d, Enfermedad: %s]\n", paciente_actual->nombre, paciente_actual->edad, paciente_actual->enfermedad);
        paciente_actual = next(L_b);  
      }
      printf("\n");
      free(paciente_actual);
      PresionaEnter();
      return;

    case '2':
      printf("Lista de pacientes en media prioridad:\n\n"); //Mostramos la lista de media prioridad
      paciente_actual = (struct paciente *)first(L_m);
      for (int i = 0; i < get_size(L_m); i++) {
        printf("[Nombre: %s, Edad: %d, Enfermedad: %s]\n", paciente_actual->nombre, paciente_actual->edad, paciente_actual->enfermedad);
        paciente_actual = next(L_m);  
      }
      printf("\n");
      free(paciente_actual);
      PresionaEnter();
      return;
  
    case '3':
      printf("Lista de pacientes en alta prioridad:\n\n"); //Mostramos la lista de alta prioridad
      paciente_actual = (struct paciente *)first(L_a);
      for (int i = 0; i < get_size(L_a); i++) {
        printf("[Nombre: %s, Edad: %d, Enfermedad: %s]\n", paciente_actual->nombre, paciente_actual->edad, paciente_actual->enfermedad);
        paciente_actual = next(L_a);  
      }
      printf("\n");
      free(paciente_actual);
      PresionaEnter();
      return;
    
    default:
      printf("Opción inválida.\n");
      PresionaEnter();
      return;

  } 
  
}

// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("\n========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir");
}

int main() {
  char opcion;
  //Lista de pacientes segun prioridad
  List *baja_prioridad = create_list();
  List *media_prioridad = create_list();
  List *alta_prioridad = create_list();

  

  while(1) {
    mostrarMenuPrincipal();

    //opciones
    printf("Ingrese una opción: ");
    scanf(" %c", &opcion);
    switch (opcion) {
      case '1':
        // Registrar paciente
        registrar_paciente(baja_prioridad, media_prioridad);
        break;
      
      case '2':
        // Asignar prioridad a paciente
        asignar_prioridad(baja_prioridad, media_prioridad, alta_prioridad);
        break;

      case '3':
        // Mostrar lista de espera
        mostrar_lista(baja_prioridad, media_prioridad, alta_prioridad);
        break;

      case '4':
        // Atender al siguiente paciente
        atender_paciente(baja_prioridad, media_prioridad, alta_prioridad);
        break;

      case '5':
        // Mostrar pacientes por prioridad
        mostrar_prioridad(baja_prioridad, media_prioridad, alta_prioridad);
        break;
      
      case '6':
        // Salir
        return 0;
    }

  }

}
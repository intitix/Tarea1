#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    void *data;
    struct Node *next;
} Node;

typedef struct List {
    Node *head;
    Node *current;
    int size;
} List;

List* create_list() {
    List* L = (List*)malloc(sizeof(List));
    if (L != NULL) {
        L->head = NULL;
        L->current = NULL;
        L->size = 0;
    }
    return L;
}

void* first(List *L) {
    if (L->size == 0) {
        return NULL;
    }
    L->current = L->head;
    return L->current->data;
}

void* next(List *L) {
    if (L->current == NULL || L->current->next == NULL) {
        return NULL;
    }
    L->current = L->current->next;
    return L->current->data;
}

void pushFront(List *L, void *dato) {
    Node *new_node = (Node*)malloc(sizeof(Node));
    if (new_node != NULL) {
        new_node->data = dato;
        new_node->next = L->head;
        L->head = new_node;
        L->current = new_node;
        L->size++;
    }
}

void pushBack(List *L, void *dato) {
    Node *new_node = (Node*)malloc(sizeof(Node));
    if (new_node != NULL) {
        new_node->data = dato;
        new_node->next = NULL;
        if (L->head == NULL) {
            L->head = new_node;
        } else {
            Node *current = L->head;
            while (current->next != NULL) {
                current = current->next;
            }
            current->next = new_node;
        }
        L->current = new_node;
        L->size++;
    }
}

void pushCurrent(List *L, void *dato) {
    if (L->current == NULL) {
        pushFront(L, dato);
    } else {
        Node *new_node = (Node*)malloc(sizeof(Node));
        if (new_node != NULL) {
            new_node->data = dato;
            new_node->next = L->current->next;
            L->current->next = new_node;
            L->current = new_node;
            L->size++;
        }
    }
}

void* popFront(List *L) {
    if (L->size == 0) {
        return NULL;
    }
    Node *temp = L->head;
    void *dato = temp->data;
    L->head = temp->next;
    free(temp);
    L->size--;
    return dato;
}

void* popBack(List *L) {
    if (L->size == 0) {
        return NULL;
    }
    Node *prev = NULL;
    Node *current = L->head;
    while (current->next != NULL) {
        prev = current;
        current = current->next;
    }
    void *dato = current->data;
    if (prev != NULL) {
        prev->next = NULL;
    } else {
        L->head = NULL;
    }
    free(current);
    L->size--;
    return dato;
}

void* popCurrent(List *L) {
    if (L->size == 0 || L->current == NULL) {
        return NULL;
    }
    Node *prev = NULL;
    Node *current = L->head;
    while (current != L->current) {
        prev = current;
        current = current->next;
    }
    void *dato = current->data;
    if (prev != NULL) {
        prev->next = current->next;
    } else {
        L->head = current->next;
    }
    free(current);
    L->size--;
    return dato;
}

int get_size(List *L) {
    return L->size;
}

void clean(List *L) {
    while (L->size > 0) {
        popFront(L);
    }
    L->current = NULL;
}